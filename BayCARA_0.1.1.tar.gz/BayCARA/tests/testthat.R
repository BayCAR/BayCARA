library(testthat)
library(BayCARA)

test_check("BayCARA")
