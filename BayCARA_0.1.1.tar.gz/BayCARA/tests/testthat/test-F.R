test_that("Expected equal", {
  planned.sample.size= 200; delay=0.5; delays=floor(planned.sample.size/4*delay);premu=82; presd=50; mu0=82 ;mu1=84; mu2=86; mu3=90; premu=c(mu1,mu2,mu3)

  sd0=sd1=sd2=sd3=sd4= 12

  data = data.frame("gender" = rep(NA, planned.sample.size), "age"=NA, continuous1=NA, continuous2=NA, group=NA, y=NA, stringsAsFactors = TRUE)

  group.level=c("0", "A", "B", "C" )

  tgroup.level=group.level[-1]

  ratio=rep(1, length(group.level))

  ratio=ratio/sum(ratio)

  data$gender[1:length(group.level)] =sample(c("female", "male"), length(group.level), TRUE, c(.6, .4))

  data$age[1:length(group.level)]=sample(c("<=40", "40-65", ">65"), length(group.level), TRUE, c(.5, .5, .5))

  data$continuous1[1:length(group.level)]=rnorm(length(group.level))

  data$continuous2[1:length(group.level)]=rnorm(length(group.level))

  data$group[1:length(group.level)]=sample(group.level, length(group.level))

  mus=c(mu0, mu1, mu2, mu3); sds=c(sd0, sd1, sd2, sd3)

  for (ig in 1:length(group.level))

  {data$y[data$group==group.level[ig]]=rnorm(sum(data$group==group.level[ig],na.rm=TRUE), mus[ig], sds[ig])}
  n.runin=round(planned.sample.size/3)
  si=start=sum(!is.na(data$group))+1
  pRA= rep(1, length(group.level))

  for (si in start:planned.sample.size)
  {data$gender[si] = sample(c("female", "male"), 1, TRUE, c(.6, .4))
  data$age[si]= sample(c("<=40", "40-65", ">65"), 1, TRUE, c(.5, .5, .5))
  data$continuous1[si]=rnorm(1)
  data$continuous2[si]=rnorm(1)
  n.run=n.runin+0:5*50

  # If interim BCARA, use (si%in%n.run)
  # If continuous BCARA, use (si>start)
  if (si%in%n.run)
  {tdata=data.frame(trt=data$group[!is.na(data$group)], y=data$y[!is.na(data$group)])
  tdata=tdata[tdata$trt!="0",]
  tdata=tdata[order(tdata$trt),]
  pRA=postP.Nfun(tdata, premu, presd)
  pRA=pRA/sum(pRA)
  pRA=c(max(pRA)[1], pRA)
  ratio=pRA}

  datat=data

  runF0=F.BayCARA(data, categorical.covariates = c("gender", "age"),  continuous.covariates = c("continuous1", "continuous2"), group.level=group.level, planned.sample.size=planned.sample.size, pRA=pRA, tuning =1 )

  data$group[si]=runF0[[1]]

  if (si> delays)
  {if (data$group[si-delays]=="0") {data$y[si-delays]=rnorm(1, mu0, sd0)}
    if (data$group[si-delays]=="A") {data$y[si-delays]=rnorm(1, mu1, sd1)}
    if (data$group[si-delays]=="B") {data$y[si-delays]=rnorm(1, mu2, sd2)}
    if (data$group[si-delays]=="C") {data$y[si-delays]=rnorm(1, mu3, sd3)}
    if (data$group[si-delays]=="D") {data$y[si-delays]=rnorm(1, mu4, sd4)}
  }
  }

  datay=data[!is.na(data$y),]
  datan=data[is.na(data$y),]
  datan$y[datan$group=="0"]=rnorm(sum(datan$group=="0"), mu0, sd0)
  datan$y[datan$group=="A"]=rnorm(sum(datan$group=="A"), mu1, sd1)
  datan$y[datan$group=="B"]=rnorm(sum(datan$group=="B"), mu2, sd2)
  datan$y[datan$group=="C"]=rnorm(sum(datan$group=="C"), mu3, sd3)

  data=rbind(datay, datan)


  expect_equal(sum(is.na(data$group)), 0)
})
