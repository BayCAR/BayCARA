#' The F.BayCARA function
#'
#' @param data  A data frame that contain the covariates to be randomized.
#'
#' @param group.var The name of the grouping variable. If none, then skip.The default is group.
#'
#' @param categorical.covariates  A list of categorical covariates to be balanced.
#'
#' @param continuous.covariates A list of continuous covariates to be balanced.
#'
#' @param group.level A list of all potential groups.
#'
#' @param ratio The assignment ratio for groups listed in group.level.
#'
#' @param categorical.weights A list of weighting factors for the categorical covariates.
#'
#' @param continuous.weights  A list of weighting factors for the continuous covariates.
#'
#' @param start.number  From which subject that the continuous covariates will be balanced.
#'
#' @param num.categories  The number of categories for the categorical variable that a continuous covariate will be converted to. The defalut is 4.
#'
#' @param pct.deterministic  The percentage of subjects will be assigned to a group in a more deterministic manner.
#'
#' @param planned.sample.size  The planned sample size for the study.
#'
#' @param pRA The calculated Response randomization probabilities.
#'
#' @param tuning  The tuning parameter.
#'
#' @examples
#'
#' planned.sample.size= 200; delay=0.5; delays=floor(planned.sample.size/4*delay)
#' premu=82; presd=50; mu0=82 ;mu1=84; mu2=86; mu3=90; premu=c(mu1,mu2,mu3)
#'
#' sd0=sd1=sd2=sd3=sd4= 12
#'
#' data = data.frame("gender" = rep(NA, planned.sample.size), "age"=NA, continuous1=NA,
#' continuous2=NA, group=NA, y=NA, stringsAsFactors = TRUE)
#'
#' group.level=c("0", "A", "B", "C" )
#'
#' tgroup.level=group.level[-1]
#'
#' ratio=rep(1, length(group.level))
#'
#' ratio=ratio/sum(ratio)
#'
#' data$gender[1:length(group.level)] =sample(c("female", "male"), length(group.level),
#' TRUE, c(.6, .4))
#'
#' data$age[1:length(group.level)]=sample(c("<=40", "40-65", ">65"), length(group.level),
#' TRUE, c(.5, .5, .5))
#'
#' data$continuous1[1:length(group.level)]=rnorm(length(group.level))
#'
#' data$continuous2[1:length(group.level)]=rnorm(length(group.level))
#'
#' data$group[1:length(group.level)]=sample(group.level, length(group.level))
#'
#' mus=c(mu0, mu1, mu2, mu3); sds=c(sd0, sd1, sd2, sd3)
#'
#' for (ig in 1:length(group.level))
#'
#' {data$y[data$group==group.level[ig]]=rnorm(sum(data$group==group.level[ig],na.rm=TRUE),
#' mus[ig], sds[ig])}
#' n.runin=round(planned.sample.size/3)
#' si=start=sum(!is.na(data$group))+1
#' pRA= rep(1, length(group.level))
#'
#' for (si in start:planned.sample.size)
#' {data$gender[si] = sample(c("female", "male"), 1, TRUE, c(.6, .4))
#' data$age[si]= sample(c("<=40", "40-65", ">65"), 1, TRUE, c(.5, .5, .5))
#' data$continuous1[si]=rnorm(1)
#' data$continuous2[si]=rnorm(1)
#' n.run=n.runin+0:5*50
#'
#' # If interim BCARA, use (si%in%n.run)
#' # If continuous BCARA, use (si>start)
#' if (si%in%n.run)
#' {tdata=data.frame(trt=data$group[!is.na(data$group)], y=data$y[!is.na(data$group)])
#' tdata=tdata[tdata$trt!="0",]
#' tdata=tdata[order(tdata$trt),]
#' pRA=postP.Nfun(tdata, premu, presd)
#' pRA=pRA/sum(pRA)
#' pRA=c(max(pRA)[1], pRA)
#' ratio=pRA}
#'
#' datat=data
#'
#' runF0=F.BayCARA(data, categorical.covariates = c("gender", "age"),
#' continuous.covariates = c("continuous1", "continuous2"), group.level=group.level,
#' planned.sample.size=planned.sample.size, pRA=pRA, tuning =1 )
#'
#' data$group[si]=runF0[[1]]
#'
#' if (si> delays)
#' {if (data$group[si-delays]=="0") {data$y[si-delays]=rnorm(1, mu0, sd0)}
#'   if (data$group[si-delays]=="A") {data$y[si-delays]=rnorm(1, mu1, sd1)}
#'   if (data$group[si-delays]=="B") {data$y[si-delays]=rnorm(1, mu2, sd2)}
#'   if (data$group[si-delays]=="C") {data$y[si-delays]=rnorm(1, mu3, sd3)}
#'   if (data$group[si-delays]=="D") {data$y[si-delays]=rnorm(1, mu4, sd4)}
#' }
#' }
#'
#' datay=data[!is.na(data$y),]
#' datan=data[is.na(data$y),]
#' datan$y[datan$group=="0"]=rnorm(sum(datan$group=="0"), mu0, sd0)
#' datan$y[datan$group=="A"]=rnorm(sum(datan$group=="A"), mu1, sd1)
#' datan$y[datan$group=="B"]=rnorm(sum(datan$group=="B"), mu2, sd2)
#' datan$y[datan$group=="C"]=rnorm(sum(datan$group=="C"), mu3, sd3)
#'
#' data=rbind(datay, datan)
#'
#' Bout=table(data$group)
#' prt=rbind(Bout,  c(round(mean(data$y[data$group=="0"]),2),
#'                    round(mean(data$y[data$group=="A"]),2),
#'                    round(mean(data$y[data$group=="B"]),2),
#'                    round(mean(data$y[data$group=="C"]),2) ))
#'
#' prt=data.frame(prt)
#' print(prt)
#'
#' inc=c("0",names(prt)[1+ which(prt[2,2:4]==max(prt[2,2:4]))[1]])
#'
#' ttdata=data.frame(trt=data$group[!is.na(data$group)],
#'                   y=data$y[!is.na(data$group)])
#' ttdata=ttdata[ttdata$trt%in%inc,]
#'
#' ttdata=ttdata[order(ttdata$trt),]
#'
#' ppRA=postP.Nfun(ttdata, c(mu0,premu[which(prt[2,2:4]==max(prt[2,2:4]))[1]]), presd)
#' pwr=ppRA[2]
#' print(pwr)
#'
#' @export

F.BayCARA=function(data, group.var, categorical.covariates, continuous.covariates, group.level, ratio, categorical.weights, continuous.weights, start.number, num.categories, pct.deterministic, planned.sample.size, pRA, tuning)
{ if (missing(planned.sample.size)) {planned.sample.size=nrow(data)
print("Please provide the planned sample size for this study by adding, for example, 'planned.sample.size=100' as the last component of the FUN.BCAR function. If not, then the randomization could be more deterministic.")}
  if (missing(num.categories)) {num.categories=3}
  if (missing(pct.deterministic)) {pct.deterministic=0.05}
  if (missing(start.number)) {start.number=15}
  if (missing(group.level)) {group.level=c("A", "B")}
  contin=cat.biasing=cont.biasing=1
  if (missing(continuous.covariates)) {contin=0} else {qk=rep(num.categories+1, length(continuous.covariates))}
  if (missing(ratio)) {ratio=rep(1, length(group.level))}
  if (missing(categorical.weights)&!missing(categorical.covariates)) {categorical.weights=rep(1, length(categorical.covariates))}
  if (missing(continuous.weights)&!missing(continuous.covariates)) {continuous.weights=rep(1, length(continuous.covariates))}
  start.seq=rep(sample(group.level, length(group.level), replace = FALSE),1)
  #  if (missing(group.var)) {data$group=NA}

  if (!missing(group.var)) {if (any(names(data)%in%group.var))
  {data$group=data[, group.var]}}

  #The number of subjects that have already been randomized;

  n.already.randomized=sum(!is.na(data$group))
  if (n.already.randomized==nrow(data)) {n.already.randomized=sum(data$group!="")}
  #print(n.already.randomized)
  # The randomization starts from the first subject that has not been randomized;
  start=n.already.randomized+1
  if (start<=nrow(data))
  {existing.groups=unique(data$group[1:n.already.randomized])
  non.levels=group.level[which(!group.level%in%existing.groups)]
  # The codes immediately generate permutated block randomization for the run-in period;
  if (length(non.levels)!=0)
  {n.permutation=start:min(nrow(data),(start-1+length(non.levels)))
  data$group[n.permutation]=c(non.levels, start.seq)[1:length(n.permutation)]}

  # Once the run-in period allocations are defined, re-define the first subject to start BayCAR;
  n.already.randomized=sum(!is.na(data$group))
  if (n.already.randomized==nrow(data)) {n.already.randomized=sum(data$group!="")}
  #print(n.already.randomized)
  # The randomization starts from the first subject that has not been randomized;
  start=n.already.randomized+1

  if (start<=nrow(data))
  {
    if (missing(categorical.covariates)&(contin==0)) {data$group[start:start.number]=sample(group.level, start.number-start+1, replace = TRUE)}
    else
    {#data$group[start:nrow(data)]=NA
      #      for (i in start:nrow(data))
      #  {

      ii=start
      if (!missing(categorical.covariates))
        # calculating biasing probability for each of the categorical covariates
      {for (j in 1:length(categorical.covariates))
      {cat.biasing.prob.out=FUN.AdaptP(data, ii, categorical.covariates[j], ratio, categorical.weights[j])*pRA
      cat.biasing.prob.out=cat.biasing.prob.out/sum(cat.biasing.prob.out)
      if (j==1) {cat.biasing=cat.biasing.prob.out} else
      {cat.biasing=cat.biasing*cat.biasing.prob.out}
      }
      }

      # For continuous covariates, we do not consider them until the number of randomized subjects
      # has reached start.number, which is preset arbitrarily;
      data$cont.to.cat=NA
      if (contin&(ii>start.number))
      {
        for (k in 1:length(continuous.covariates))
        {cont=data[1:ii,continuous.covariates[k]]
        ncc=stats::quantile(cont, seq(0,1, length.out=qk[k]))
        ncc=ncc[-c(1, length(ncc))]
        data$cont.to.cat[1:ii]=1
        for (l in 1:length(ncc))
        {data$cont.to.cat[1:ii][cont>ncc[l]]=(l+1)
        }
        cont.biasing.prob.out=FUN.AdaptP(data, ii, "cont.to.cat", ratio, continuous.weights[k])*pRA

        cont.biasing.prob.out=cont.biasing.prob.out/sum(cont.biasing.prob.out)
        # if (length(unique(cont.biasing.prob.out))) {qk[k]=qk[k]+1; k=k-1}
        if (k==1) {cont.biasing=cont.biasing.prob.out} else
        {cont.biasing=cont.biasing*cont.biasing.prob.out}
        }}

      PPP=cat.biasing*cont.biasing
      #      print(PPP); print(pRA); print(pRA^tuning)
      PPP=PPP^tuning

      PPP=PPP/sum(PPP)
      nc= floor((1-pct.deterministic) *planned.sample.size)
      if (ii> nc)
      {pwhtrt=sample(group.level, 1, prob=PPP^(seq(2, 9, length.out = nrow(data)-nc)[ii-nc]))} else
      {pwhtrt=sample(group.level, 1, prob=PPP)}

    }
  }
  }
  return(list(sample(pwhtrt,1), PPP))
}
