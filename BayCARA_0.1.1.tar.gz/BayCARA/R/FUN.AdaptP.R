
###################################################################################3
#################################################################################
#' The FUN.AdaptP function
#'
#' @param data  A data frame that contain the covariates to be randomized.
#'
#' @param ji The index of the subject to be randomized.
#'
#' @param covj  The name of the covariate, for which is biasing randomization probability will be calculated.
#'
#' @param ratio  The assignment ratio for groups listed in group.level.
#'
#' @param weights The weights of the covariate.
#'
#' @param group.level A list of all potential groups.
#'
#' @export

# The function for calculating biasing randomization probability
FUN.AdaptP=function(data, ji, covj, ratio, weights, group.level)
{ink=0
if (covj=="group") {tg=t(table(data[,"group"]))} else
{tg= table(data[1:ji,covj], factor(data$group[1:ji], levels = group.level)) }

if (all(abs(tg[,1]-tg[,2])<1)) {ink=1}

gi=data[ji, covj]
frq0=frq=t(tg[row.names(tg)==gi,])

if (all(frq==0)) {} else {frq=frq  /ratio    #*sum(ratio)/min(ratio)# *100
frq=frq*sum(frq0)/sum(frq)}
g.out=postP.Bfun(frq)
if (length(weights)==1) {weights=rep(1, length(g.out))}

g.out=g.out^weights

return (g.out)
}
