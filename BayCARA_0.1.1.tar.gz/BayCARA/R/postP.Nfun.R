#' The postP.Nfun function
#'
#' @param tdata  A data frame that contains the covariate and response data.
#'
#' @param premu  The means of the prior distributions. It can be a vector (each element represent one prior distribution) or a scalar (the same value for all the prior distributions).
#'
#' @param presd  The SDs of the prior distributions. It can be a vector (each element represent one prior distribution) or a scalar (the same value for all the prior distributions).
#'
#' @examples
#' tdata = data.frame("gender" = sample(c("female", "male"), 100, TRUE, c(.5, .5)))
#' tdata$age = sample(c("<=50", ">50"), 100, TRUE, c(.5, .5))
#' tdata$trt= sample(c("A", "B", "C"), 100, replace =TRUE)
#' tdata$y=rnorm(100, 3)
#' postP.Nfun(tdata, premu=3.1, presd=.9)
#'
#' @export


###########################
# Function for calculating biasing probabilities
postP.Nfun=function(tdata, premu, presd)
{ntrt=sort(unique(tdata$trt))
  nntrt=length(ntrt)
  if (length(premu)==1) {premu=rep(premu, nntrt)}
  if (length(presd)==1) {presd=rep(presd, nntrt)}
  outi=cbind(rep(NA, nntrt),rep(NA, nntrt),rep(NA, nntrt),rep(NA, nntrt),rep(NA, nntrt))
      for (i in 1:length(ntrt))
          {datasi=tdata$y[tdata$trt==ntrt[i]]
          outi[i,1]=mean(datasi,na.rm=TRUE)
          outi[i,2]=stats::sd(datasi,na.rm=TRUE)
          outi[i,3]=sum(!is.na(datasi))
          postdist=post.fun(premu[i], presd[i], outi[i,1], outi[i,2], outi[i,3])
          outi[i,4]=postdist[1]
          outi[i,5]=postdist[2]
          }
      for (i in 1:length(ntrt))
          {
            {outii=rbind(outi[i,], outi[-i,])}
              Pi=stats::integrate(N.int, lower=-Inf, upper=Inf,outii)$value
          if (i==1) {pout=Pi} else {pout=c(pout, Pi)}
          }

allP=sqrt(pout/sum(pout))
if (all(allP==0)) {allP=1+allP}
return(allP/sum(allP))
}
