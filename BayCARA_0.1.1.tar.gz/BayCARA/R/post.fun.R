#' The post.fun function
#'
#' @param premu  The means of the prior distributions. It can be a vector (each element represent one prior distribution) or a scalar (the same value for all the prior distributions).
#'
#' @param presd  The SDs of the prior distributions. It can be a vector (each element represent one prior distribution) or a scalar (the same value for all the prior distributions).
#'
#' @param mdata A vector of observed data mean per group..
#'
#' @param sddata  A vector of observed data SD per group..
#'
#' @param sizes A vector of size per group.
#'
#' @examples
#'
#' post.fun (premu=c(3,3,3), presd=c(1,1,1), mdata=c(3.1,3.2,3.3), sddata=c(1,1,1), sizes=c(20,30,25))
#'
#' @export


#######################################
# Function for calculating posterior distributions
post.fun=function(premu, presd, mdata, sddata, sizes)
{#pmu=(premu_t/(presd_t)^2+mean(datas)/(sd(datas)^2)*sizes)/(1/(presd_t)^2+1/sd(datas)^2*sizes)
  pmu=(premu/presd^2+sizes*mdata/sddata^2)/(1/presd^2+sizes/sddata^2)
  #psd=sqrt(1/(1/(presd_t)^2+1/sd(datas)^2*sizes))
  psd=sqrt(1/(1/presd^2+sizes/sddata^2))
  return(c(pmu, psd))
}
