#' The N.int function
#'
#' @param x  A variable for integraton.
#'
#' @param outdata A data frame contains the posterior means and SDs for all the groups.
#'
#' @examples
#'
#' # This is the numerical integration function. Do not need to be run independently.
#'
#' @export


##############################################################################
##############################################################################
# The integration function for normal distributions
N.int = function(x, outdata)
{for (i in 2:nrow(outdata))
{pi= 1-stats::pnorm(x,(outdata[1,4]-outdata[i,4])/outdata[i,5],outdata[1,5]/outdata[i,5])
if (i==2) {pp=pi} else {pp=pp*pi}
}
  di=stats::dnorm(x)
  pp*di
}

